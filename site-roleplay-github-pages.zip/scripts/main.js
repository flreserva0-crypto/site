const CONFIG = {
  nome: "MEU SERVIDOR",
  subtitulo: "Roleplay",
  plataforma: "MTA",
  slots: "500",
  discord: "https://discord.gg/seuservidor",
  jogar: "#"
};

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-server-name]").forEach(el => el.textContent = CONFIG.nome);
  document.querySelectorAll("[data-server-subtitle]").forEach(el => el.textContent = CONFIG.subtitulo);
  document.querySelectorAll("[data-platform]").forEach(el => el.textContent = CONFIG.plataforma);
  document.querySelectorAll("[data-slots]").forEach(el => el.textContent = CONFIG.slots);
  document.querySelectorAll("[data-discord]").forEach(el => el.href = CONFIG.discord);
  document.querySelectorAll("[data-play]").forEach(el => el.href = CONFIG.jogar);

  document.title = `${CONFIG.nome} • ${CONFIG.subtitulo}`;
  document.getElementById("year").textContent = new Date().getFullYear();

  const menu = document.getElementById("mobileMenu");
  const nav = document.getElementById("navLinks");

  menu.addEventListener("click", () => nav.classList.toggle("open"));
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
});

function comprar(produto) {
  const toast = document.getElementById("toast");
  const text = document.getElementById("toastText");
  text.textContent = `${produto} selecionado. Configure sua loja para finalizar pagamentos.`;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}
